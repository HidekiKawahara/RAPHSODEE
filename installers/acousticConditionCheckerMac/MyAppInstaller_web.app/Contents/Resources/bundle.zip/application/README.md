# src

## Prerelease application

The acousticConditionChecker application is an integrated tool for testing acoustic environments using several test signals.
The reverbeLmbrdSpeechTesterRev application is an interactive and realtime test tool for acoustic environment on speech production.

### Test environment

MacBookPro M1 max 14 inch 2021, 64GB macOS Sonoma 14.0

MATLAB R2024a Update-3
Signal Processing Toolbox
(This application does not require AudioToolbox)

## Obsolete applications

 rhapsodeeControlTool.mlapp
 reverbeSpeechTester.mlapp
 raphsodeeAcousticTool.mlapp
